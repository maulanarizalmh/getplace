from qgis.core import (QgsProcessingAlgorithm, QgsProcessingParameterVectorLayer, 
                       QgsProcessingParameterString, QgsProcessing, QgsVectorLayer, 
                       QgsFeature, QgsGeometry, QgsPointXY, QgsField, QgsProject)
from qgis.PyQt.QtCore import QVariant 
import requests
import json

class GetPlacesByNameAlgorithm(QgsProcessingAlgorithm):
    """QGIS Processing algorithm to fetch place data based on name keywords from Overpass API"""
    
    POLYGON_LAYER = 'POLYGON_LAYER'
    PLACE_NAME_KEYWORDS = 'PLACE_NAME_KEYWORDS'
    
    def initAlgorithm(self, config=None):
        """Define the inputs for the algorithm"""
        
        # Input for the polygon layer
        self.addParameter(
            QgsProcessingParameterVectorLayer(
                self.POLYGON_LAYER,
                'Polygon Layer',
                types=[QgsProcessing.TypeVectorPolygon]
            )
        )
        
        # Input for the place name keywords
        self.addParameter(
            QgsProcessingParameterString(
                self.PLACE_NAME_KEYWORDS,
                'Name Keywords (e.g., cafe, clinic, hospital)',
                defaultValue=""
            )
        )
    
    def processAlgorithm(self, parameters, context, feedback):
        """Run the algorithm to fetch places based on keywords in place names and create a new point layer"""
        
        # Get the inputs from the user
        polygon_layer = self.parameterAsVectorLayer(parameters, self.POLYGON_LAYER, context)
        name_keywords = self.parameterAsString(parameters, self.PLACE_NAME_KEYWORDS, context)
        
        if polygon_layer is None or not polygon_layer.isValid():
            feedback.reportError('Invalid polygon layer')
            return {}

        if not name_keywords:
            feedback.reportError('Name keywords input is empty')
            return {}

        # Split keywords by commas or spaces and handle multiple keywords
        keywords_list = [kw.strip() for kw in name_keywords.split(",") if kw.strip()]

        if not keywords_list:
            feedback.reportError('No valid keywords provided')
            return {}

        # Feedback log for keywords
        feedback.pushInfo(f"Starting search for keywords: {', '.join(keywords_list)}")
        
        # Collect features
        all_features = []
        total_polygons = polygon_layer.featureCount()
        processed_polygons = 0

        # Iterate through each polygon in the layer
        for polygon_feature in polygon_layer.getFeatures():
            polygon_geom = polygon_feature.geometry()
            polygon_coords = self.get_polygon_coordinates(polygon_geom)
            
            if polygon_coords:
                processed_polygons += 1
                
                # Update progress
                progress = int((processed_polygons / total_polygons) * 100)
                feedback.setProgress(progress)
                feedback.pushInfo(f"Processing polygon {processed_polygons} of {total_polygons}...")

                feedback.pushInfo(f"Querying Overpass API for the current polygon area...")
                
                # Fetch places from Overpass API using name keywords
                places = self.fetch_places_by_name(polygon_coords, keywords_list, feedback)
                
                if places and 'elements' in places:
                    feedback.pushInfo(f"Received {len(places['elements'])} results, processing...")
                    
                    for element in places['elements']:
                        if element['type'] == 'node':
                            lon = element['lon']
                            lat = element['lat']
                        elif element['type'] == 'way':
                            lon = element['center']['lon']
                            lat = element['center']['lat']
                        else:
                            continue  # Skip unknown types
                            
                        # Create point geometry
                        point_geom = QgsGeometry.fromPointXY(QgsPointXY(lon, lat))

                        # Create a feature and set its attributes
                        feature = QgsFeature()
                        feature.setGeometry(point_geom)
                        
                        # Extract attributes from the element
                        name = element.get('tags', {}).get('name', 'Unnamed')
                        address = element.get('tags', {}).get('addr:full', 'No Address')

                        # Store the entire raw element as JSON
                        raw_data = json.dumps(element)

                        # Collect attributes: raw data, name, address, latitude, longitude
                        attributes = [raw_data, name, address, lat, lon]

                        # Set feature attributes
                        feature.setAttributes(attributes)

                        # Collect the feature
                        all_features.append(feature)

        # Final progress update
        feedback.setProgress(100)
        feedback.pushInfo(f"Total features collected: {len(all_features)}")
        
        # Create the point layer with simplified fields
        result_layer_name = f"Places_with_{'_'.join(keywords_list)}"
        point_layer = self.create_point_layer(result_layer_name)
        point_layer_dp = point_layer.dataProvider()
        
        # Add all collected features to the point layer
        if all_features:
            point_layer_dp.addFeatures(all_features)
            feedback.pushInfo(f"Added {len(all_features)} features to the layer.")
        else:
            feedback.pushInfo("No features to add.")

        # Update the extents and fields
        point_layer.updateExtents()
        point_layer.updateFields()
        
        # Add the point layer to the project
        QgsProject.instance().addMapLayer(point_layer)
        feedback.pushInfo(f"Point layer with places containing '{name_keywords}' in their names has been created and added to the project.")

        return {}

    def create_point_layer(self, name):
        """Create a memory point layer with simplified fields and a given name"""
        point_layer = QgsVectorLayer("Point?crs=EPSG:4326", name, "memory")
        point_layer_data_provider = point_layer.dataProvider()
        
        # Add fields for raw data, name, address, latitude, and longitude
        fields = [
            QgsField("raw_data", QVariant.String),  # Column to store raw JSON data
            QgsField("name", QVariant.String),
            QgsField("address", QVariant.String),
            QgsField("latitude", QVariant.Double),
            QgsField("longitude", QVariant.Double)
        ]
        
        point_layer_data_provider.addAttributes(fields)
        point_layer.updateFields()
        
        return point_layer

    def get_polygon_coordinates(self, polygon_geom):
        """Convert the polygon geometry into a string format suitable for Overpass API"""
        if not polygon_geom.isMultipart():
            polygons = [polygon_geom.asPolygon()]
        else:
            polygons = polygon_geom.asMultiPolygon()

        if len(polygons) == 0:
            return None
        
        polygon_coords = []
        for polygon in polygons:
            for ring in polygon:
                for point in ring:
                    # Overpass API expects the coordinates in (longitude, latitude) order
                    lon, lat = point.x(), point.y()
                    polygon_coords.append(f"{lat} {lon}")
        
        return " ".join(polygon_coords)

    def fetch_places_by_name(self, polygon_coords, keywords_list, feedback):
        """Query Overpass API to fetch places inside the polygon based on keywords in the place name"""
        overpass_url = "http://overpass-api.de/api/interpreter"
        
        # Build the query dynamically from the keywords list
        name_conditions = " | ".join([f'name~"{kw}", i' for kw in keywords_list])

        # Query Overpass for places with matching names
        overpass_query = f"""
        [out:json];
        (
          node[{name_conditions}](poly:"{polygon_coords}");
          way[{name_conditions}](poly:"{polygon_coords}");
        );
        out center;
        """
        
        try:
            response = requests.post(overpass_url, data={"data": overpass_query})
            response.raise_for_status()  # Raises an exception for non-200 status codes
            json_response = response.json()
            feedback.pushInfo(f"Overpass API response: {json.dumps(json_response, indent=2)}")
            return json_response
        except requests.RequestException as e:
            feedback.reportError(f"Error fetching data from Overpass API: {str(e)}")
            return None

    def name(self):
        """Return unique algorithm name"""
        return "get_places_by_name"

    def displayName(self):
        """Return display name"""
        return "Get Places by Name"

    def group(self):
        """Return empty group to avoid grouping"""
        return ""

    def groupId(self):
        """Return empty group id"""
        return ""

    def createInstance(self):
        """Required to clone the algorithm""" 
        return GetPlacesByNameAlgorithm() 
 
# Register the algorithm with the QGIS Processing Toolbox 
def registerAlgorithm(): 
    from qgis.core import QgsApplication 
    QgsApplication.processingRegistry().addAlgorithm(GetPlacesByNameAlgorithm()) 
