from qgis.core import (QgsProcessingAlgorithm, QgsProcessingParameterVectorLayer, QgsProcessingParameterString, QgsProcessing, QgsVectorLayer, QgsFeature, QgsGeometry, QgsPointXY, QgsField, QgsProject) 
from qgis.PyQt.QtCore import QVariant 
import requests

class GetPlacesAlgorithm(QgsProcessingAlgorithm):
    """QGIS Processing algorithm to fetch place data based on amenity type from Overpass API"""
    
    POLYGON_LAYER = 'POLYGON_LAYER'
    PLACE_AMENITY = 'PLACE_AMENITY'
    
    def initAlgorithm(self, config=None):
        """Define the inputs for the algorithm"""
        
        # Input for the polygon layer
        self.addParameter(
            QgsProcessingParameterVectorLayer(
                self.POLYGON_LAYER,
                'Polygon Layer',
                types=[QgsProcessing.TypeVectorPolygon]
            )
        )
        
        # Input for the place amenity type (e.g., restaurant, school, hospital)
        self.addParameter(
            QgsProcessingParameterString(
                self.PLACE_AMENITY,
                'Amenity Type (e.g., restaurant, school, hospital)',
                defaultValue=""
            )
        )
    
    def processAlgorithm(self, parameters, context, feedback):
        """Run the algorithm to fetch places based on the amenity type and create a new point layer"""
        
        # Get the inputs from the user
        polygon_layer = self.parameterAsVectorLayer(parameters, self.POLYGON_LAYER, context)
        amenity_type = self.parameterAsString(parameters, self.PLACE_AMENITY, context)
        
        if polygon_layer is None or not polygon_layer.isValid():
            feedback.reportError('Invalid polygon layer')
            return {}

        # Create the point layer to store the results with the amenity type as the layer name
        point_layer = self.create_point_layer(amenity_type)
        point_layer_dp = point_layer.dataProvider()
        
        # Iterate through each polygon in the layer
        for polygon_feature in polygon_layer.getFeatures():
            polygon_geom = polygon_feature.geometry()
            polygon_coords = self.get_polygon_coordinates(polygon_geom)
            
            if polygon_coords:
                # Fetch places from Overpass API using amenity type (not names)
                places = self.fetch_places_from_overpass(polygon_coords, amenity_type)
                
                if places and 'elements' in places:
                    for element in places['elements']:
                        if element['type'] == 'node':
                            lon = element['lon']
                            lat = element['lat']
                            place_name = element.get('tags', {}).get('name', 'Unnamed')
                            place_type = element.get('tags', {}).get('amenity', 'Unknown')

                            # Create point geometry
                            point_geom = QgsGeometry.fromPointXY(QgsPointXY(lon, lat))

                            # Create a feature and set its attributes
                            feature = QgsFeature()
                            feature.setGeometry(point_geom)
                            feature.setAttributes([place_name, place_type, lat, lon])

                            # Add the feature to the point layer
                            point_layer_dp.addFeatures([feature])

        # Add the point layer to the project
        QgsProject.instance().addMapLayer(point_layer)
        feedback.pushInfo(f"Point layer with '{amenity_type}' places has been created and added to the project.")

        return {}

    def create_point_layer(self, amenity_type):
        """Create a memory point layer to store places with the layer name as the amenity type"""
        layer_name = f"Places_{amenity_type}"
        point_layer = QgsVectorLayer(f"Point?crs=EPSG:4326", layer_name, "memory")
        point_layer_data_provider = point_layer.dataProvider()
        
        # Add fields for place name, type, latitude, and longitude
        point_layer_data_provider.addAttributes([
            QgsField("name", QVariant.String), 
            QgsField("type", QVariant.String),
            QgsField("latitude", QVariant.Double),
            QgsField("longitude", QVariant.Double)
        ])
        point_layer.updateFields()
        
        return point_layer

    def get_polygon_coordinates(self, polygon_geom):
        """Convert the polygon geometry into a string format suitable for Overpass API"""
        if not polygon_geom.isMultipart():
            polygons = [polygon_geom.asPolygon()]
        else:
            polygons = polygon_geom.asMultiPolygon()

        if len(polygons) == 0:
            return None
        
        polygon_coords = []
        for polygon in polygons:
            for ring in polygon:
                for point in ring:
                    # Overpass API expects the coordinates in (longitude, latitude) order
                    lon, lat = point.x(), point.y()
                    polygon_coords.append(f"{lat} {lon}")
        
        return " ".join(polygon_coords)

    def fetch_places_from_overpass(self, polygon_coords, amenity_type):
        """Query Overpass API to fetch places inside the polygon based on amenity type"""
        overpass_url = "http://overpass-api.de/api/interpreter"
        overpass_query = f"""
        [out:json];
        (
          node["amenity"="{amenity_type}"](poly:"{polygon_coords}");
          way["amenity"="{amenity_type}"](poly:"{polygon_coords}");
        );
        out center;
        """
        
        response = requests.post(overpass_url, data={"data": overpass_query})
        
        if response.status_code == 200:
            return response.json()
        else:
            return None

    def name(self):
        """Return unique algorithm name"""
        return "get_places"

    def displayName(self):
        """Return display name"""
        return "Get Places by Amenity"

    def group(self):
        """Return empty group to avoid grouping"""
        return ""

    def groupId(self):
        """Return empty group id"""
        return ""

    def createInstance(self):
        """Required to clone the algorithm""" 
        return GetPlacesAlgorithm() 
 
# Register the algorithm with the QGIS Processing Toolbox 
def registerAlgorithm(): 
    from qgis.core import QgsApplication 
    QgsApplication.processingRegistry().addAlgorithm(GetPlacesAlgorithm()) 
